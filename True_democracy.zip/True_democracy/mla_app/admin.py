from django.contrib import admin
from mla_app.models import MLADetails,Complaints,MLA_posts,del_Count
# Register your models here.
admin.site.register(MLADetails)
admin.site.register(Complaints)
admin.site.register(MLA_posts)
admin.site.register(del_Count)