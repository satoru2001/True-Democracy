from django.db import models
from django.contrib.auth.models import User
from datetime import datetime, date
# Create your models here.

class MLADetails(models.Model):
    photo_link = models.URLField()
    name = models.CharField(max_length=264)
    portfolio = models.CharField(max_length=264)
    details = models.CharField(max_length=264)
    constituencies = models.CharField(max_length=264)

class Complaints(models.Model):
    constituency = models.CharField(max_length=264,null=True)
    problem = models.CharField(max_length=264)
    details = models.CharField(max_length=264)
    describe = models.CharField(max_length=264)
    government = models.CharField(max_length=264)
    comments = models.CharField(max_length=264)
    type_com = models.CharField(max_length=264)
    timestamp = models.DateField(auto_now_add=True, auto_now = False, blank = True)
    def __str__(self):
        return str(self.constituency)

class MLA_posts(models.Model):
    constituency = models.CharField(max_length=264,null=True)
    content = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    likes = models.ManyToManyField(User,related_name='MLA_posts')
    def __str__(self):
        return str(self.constituency)

class del_Count(models.Model):
    type_com = models.CharField(max_length=264)
    constituency = models.CharField(max_length=264,null=True)
    problem = models.CharField(max_length=264)
    counting = models.IntegerField(default=0)