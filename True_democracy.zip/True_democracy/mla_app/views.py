from django.shortcuts import render
from django.contrib import messages
from django.http import HttpResponse,HttpResponseRedirect
from django.urls import reverse
from mla_app.models import MLADetails,Complaints,MLA_posts,del_Count
from sign_up.models import UserProfileInfo
from . import forms
from django.core import validators
from django.http import JsonResponse
from mla_app.forms import formnew,tweetForms
from sign_up.forms import UserForm,UserProfileInfoForm
from sign_up.models import Info,UserProfileInfo

#Modules import
import geopy,requests,json,os
import tensorflow as tf
from geopy.geocoders import Nominatim,GoogleV3,ArcGIS
from geopy.extra.rate_limiter import RateLimiter
from geopy.distance import great_circle,geodesic
from tensorflow.keras.models import model_from_json
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences

from datetime import timedelta, date, datetime

def get_weighted_loss(pos_weights, neg_weights, epsilon=1e-7):
  def weighted_loss(y_true,y_pred):
    loss = 0.0
    loss += K.mean(-1*(pos_weights*y_true*K.log(y_pred+epsilon)+neg_weights*(1-y_true)*K.log(1-y_pred+epsilon)))
    return loss
  return weighted_loss

parent_dir = os.getcwd()
model_path = os.path.join(parent_dir,'MLData')
model_structure = os.path.join(model_path,'model.json')
model_weights = os.path.join(model_path,'my_model_weights.h5')
tokenizer_file = os.path.join(model_path,'mywords.json')
print(parent_dir)
with open(model_structure, "r") as json_file:
  loaded_model_json = json_file.read()
new_model = model_from_json(loaded_model_json,custom_objects={'weighted_loss':get_weighted_loss([0.2],[0.8])})
new_model.load_weights(model_weights)
json_file = open(tokenizer_file,'r')
file_tokenizer = json.load(json_file)
tokenizer_new = tf.keras.preprocessing.text.tokenizer_from_json(file_tokenizer)

def daterange(date1, date2):
	for n in range(int ((date2 - date1).days)+1):
		yield date1 + timedelta(n)


def profinity_value(sentence):
	sequence = tokenizer_new.texts_to_sequences(sentence)
	padding = pad_sequences(sequence,maxlen=20,padding = "post",truncating="post")
	return new_model.predict(padding)

def get_distance(langlog1,langlog2):
	city1 = tuple(langlog1.split(","))
	city2 = langlog2
	distance = geodesic(city1,city2)
	print(city1,city2,distance.km)
	if distance.km > 3:
		return False
	return True

def get_Location(langlog):
	locator = Nominatim(user_agent="myGeocoder")
	coordinates = langlog
	location = locator.reverse(coordinates)
	return location.raw
	# district = address['district']
	# return district

def get_LanLon(constituencies,home_address):
	locator = ArcGIS()
	district = home_address.split(",")[-2]
	address = constituencies+", "+district+", AndhraPradesh, India"
	location = locator.geocode(address)
	return (location.latitude,location.longitude)


def speci_mla(request,cname='Pulivendla'):
	zipped_list=[]
	places = MLADetails.objects.values_list('constituencies',flat=True)
	data = MLADetails.objects.get(constituencies=cname)
	tweets = list(MLA_posts.objects.all().reverse().filter(constituency=cname))
	tweets = sorted(tweets, key=lambda x: x.created, reverse=True )
	photo = data.photo_link
	name = data.name
	portfolio = data.portfolio
	details = data.details
	con = data.constituencies
	form = forms.FormName()
	form_tweet = tweetForms(request.POST)
	form2 = forms.Clear(request.POST)
	# forms.FormName.constituency = cname
	# print(forms.FormName.constituency)
	#Check to see if we get a POST back.
	if request.method == 'POST':
		# In which case we pass in that
		form = forms.FormName(request.POST)
		form_1 = formnew(request.POST)
		#form = Complaints(initial={'constituency':cname})
		#Check to see form is valid
		if form.is_valid() :
			sentence = [form.cleaned_data['details'],form.cleaned_data['describe'],form.cleaned_data['government'],form.cleaned_data['comments']]
			if not request.user.is_authenticated :
				return render(request,'sign_up/signup.html')
			if (not get_distance(form.cleaned_data['longitude'],get_LanLon(con,details))) or (max(profinity_value(sentence)) > 0.5):
				if (not get_distance(form.cleaned_data['longitude'],get_LanLon(con,details))):
					messages.error(request,'You are not in this MLA constituency')
				if (max(profinity_value(sentence)) > 0.5):
					messages.error(request,'Profinity Is a Serious offence.')
			else:
			#Do something.:
				obj = form.save(commit=True)
				obj.constituency = cname
				obj.save()
				print("form validation success")
				return thankyou(request)

		elif form_1.is_valid():
				temp="nothing"
				pro="something"			
				temp=form_1.cleaned_data['temp']
				pro=form_1.cleaned_data['pro']
				data_2 = MLADetails.objects.get(constituencies=cname)
				cons=data_2.constituencies
				u=Complaints.objects.values() 
				o=[]
				p=[]
				l=[]
				fin={}
				g=[e for e in u]
				for i in range(len(g)):
					if(g[i]['constituency']==cname):
						if(g[i]['type_com']==temp):
							if(g[i]['problem']==pro):
								o.append(g[i]['details'])
								p.append(g[i]['government'])
								l.append(g[i]['comments'])
				zipped_list = zip(o,p,l)

		elif form_tweet.is_valid() and request.user.is_authenticated:
			user = request.user
			print("Tweet : ",form_tweet.cleaned_data['content'])
			if request.user.userprofileinfo.isMLA=="mla":
				obj = form_tweet.save(commit=False)
				print("Tweet : ",form_tweet.cleaned_data['content'])
				obj.constituency = con
				obj.save()

		elif form2.is_valid():
			problem = form2.cleaned_data['problem']
			type_com = form2.cleaned_data['type_com']
			objs = Complaints.objects.all().filter(constituency=cname,type_com=type_com,problem=problem)
			start_dt = form2.cleaned_data['start_date']
			end_dt = form2.cleaned_data['end_date']
			for dt in daterange(start_dt, end_dt):
				
				temp1 = datetime.strptime(dt.strftime("%Y-%m-%d"),'%Y-%m-%d')
				
				for o in objs:
					temp2 = datetime.strptime(o.timestamp.strftime("%Y-%m-%d") ,'%Y-%m-%d')
					if (temp2 == temp1):
						counter_objs = del_Count.objects.all().filter(constituency=cname,type_com=type_com,problem=problem)
						if counter_objs:
							counter_objs = del_Count.objects.get(constituency=cname,type_com=type_com,problem=problem)
							counter_objs.counting+=1
							counter_objs.save()
						else:
							count_obj = del_Count.objects.create(constituency=cname,type_com = type_com,problem = problem,counting=1)
							count_obj.save()
						o.delete()

		else:
			print('FORM ERROR INVALID')

	all_complaints = Complaints.objects.all()

	data = {'photo':photo,'name':name,'portfolio':portfolio,'details':details,'con':con,'record':places,'form':form,'complaints':all_complaints,'context':zipped_list,'form_tweet': form_tweet,'tweets':tweets,'form2':form2}
	return render(request,'mla_app/search.html',context=data)

def thankyou(request):
	return render(request,'mla_app/thankyou.html')


#Graphs
def grpah(request,cname='Pulivendla'):
	data = MLADetails.objects.get(constituencies=cname)
	cons=data.constituencies
	u=Complaints.objects.values() 
	compress=[]
	g=[e for e in u]
	for i in range(len(g)):
		if(g[i]['constituency']==cons):
			compress.append(g[i]['problem'])
	result = dict((p, compress.count(p)) for p in compress)
	keys=[]
	vals=[]
	for v in result.values():
		vals.append(v)
	for k in result.keys():
		keys.append(k)

	final={
		"xaxis":keys,
		"yaxis":vals,
	}
	return JsonResponse(final,safe=False)

def grpah_1(request,cname='Pulivendla'):

	x=Complaints.objects.values() 
	t=[e for e in x]
	con_s=[]
	for i in range(len(t)):
		con_s.append(t[i]['constituency'])
	result = dict((p, con_s.count(p)) for p in con_s)
	# keys=["Red","Orange","Blue"]
	keys=[]
	vals=[]
	for v in result.values():
		vals.append(v)
	for k in result.keys():
		keys.append(k)

	final_1={
		"xaxis":keys,
		"yaxis":vals,
	}
	return JsonResponse(final_1,safe=False)



def grpah_2(request,cname='Pulivendla'):
	data = MLADetails.objects.get(constituencies=cname)
	cons=data.constituencies
	u=Complaints.objects.values() 
	compress=[]
	g=[e for e in u]
	for i in range(len(g)):
		if(g[i]['constituency']==cons):
			if(g[i]['type_com']=='Complaint'):
				compress.append(g[i]['problem'])

	result = dict((p, compress.count(p)) for p in compress)
	keys=[]
	vals=[]
	for v in result.values():
		vals.append(v)
	for k in result.keys():
		keys.append(k)

	final_2={
		"xaxis":keys,
		"yaxis":vals,
	}
	return JsonResponse(final_2,safe=False)

def grpah_3(request,cname='Pulivendla'):
	data = MLADetails.objects.get(constituencies=cname)
	cons=data.constituencies
	u=Complaints.objects.values() 
	compress=[]
	g=[e for e in u]
	for i in range(len(g)):
		if(g[i]['constituency']==cons):
			if(g[i]['type_com']=='Request'):
				compress.append(g[i]['problem'])

	result = dict((p, compress.count(p)) for p in compress)
	keys=[]
	vals=[]
	for v in result.values():
		vals.append(v)
	for k in result.keys():
		keys.append(k)

	final_3={
		"xaxis":keys,
		"yaxis":vals,
	}
	return JsonResponse(final_3,safe=False)

def grpah_4(request,cname='Pulivendla'):
	count=0
	data = MLADetails.objects.get(constituencies=cname)
	cons=data.constituencies
	present = del_Count.objects.values()
	h_1=[]
	h_2=[]
	h=[e for e in present]
	for i in range(len(h)):
		if(h[i]['constituency']==cname):
			if(h[i]['type_com']=='Request'):
				count=count+h[i]['counting']
	h_1.append("this constituency requests solved")
	h_2.append(count)

	final_4={
		"xaxis":h_1,
		"yaxis":h_2,
	}
	return JsonResponse(final_4,safe=False)

def grpah_5(request,cname='Pulivendla'):
	coun=0
	data = MLADetails.objects.get(constituencies=cname)
	cons=data.constituencies
	present = del_Count.objects.values()
	h_1=[]
	h_2=[]
	h=[e for e in present]
	for i in range(len(h)):
		if(h[i]['constituency']==cname):
			if(h[i]['type_com']=='Complaint'):
				coun=coun+h[i]['counting']
	h_1.append("this constituency complaints cateogry solved")
	h_2.append(coun)

	final_5={
		"xaxis":h_1,
		"yaxis":h_2,
	}
	return JsonResponse(final_5,safe=False)