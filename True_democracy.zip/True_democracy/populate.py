import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "True_democracy.settings")
import django
django.setup()

import pandas as pd
from sign_up.models import Info

def populate(N=10):
    data = pd.read_csv("b.csv",index_col=False,names=['S.No', 'Title', 'Ministry', 'Introduced in LS/RS','Passed in LS','Passed in RS'])
    print(data.head())
    #data.columns = ['S.No', 'Title', 'Ministry', 'Introduced in LS/RS','Passed in LS','Passed in RS']
    print(data)
    for i in data.index:
        S = data['S.No'][i]
        T = data['Title'][i]
        M = data['Ministry'][i]
        I = data['Introduced in LS/RS'][i]
        P = data['Passed in LS'][i]
        Pa = data['Passed in RS'][i]
        webpg = Info.objects.get_or_create(SNo = S,Title = T,Ministry = M,IntroducedinLSRS = I,PassedinLS = P,PassedinRS =Pa)[0]
if __name__=='__main__':
    populate(10)
