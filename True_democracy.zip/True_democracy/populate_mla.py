import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "True_democracy.settings")
import django
django.setup()

import pandas as pd
from mla_app.models import MLADetails

def populate():
    data = pd.read_csv("mla_db.csv",index_col=False,encoding = "ISO-8859-1")
    for i in data.index:
        link = data['photo_link'][i]
        identity = data['name'][i]
        party = data['portfolio'][i]
        add = data['details'][i]
        #print('\n\n\n')
        con = data['constituencies'][i]
        #print(con)
        #print('\n\n\n')
        webpg = MLADetails.objects.get_or_create(photo_link=link,name = identity,portfolio = party,details = add,constituencies=con)[0]
        print(webpg)

if __name__=='__main__':
    print('populating scripts')
    populate()
    print('populating completed')











