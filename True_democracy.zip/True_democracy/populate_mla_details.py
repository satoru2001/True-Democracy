import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "True_democracy.settings")
import django
django.setup()

import pandas as pd
from sign_up.models import MLA_contactinfo

def populate():
    data = pd.read_csv("data.csv")
    for i in data.index:
        for j in range(int((len(data['Phno'][i]))/10)):
            name = data['name'][i]
            number = data['Phno'][i][j*10:(j+1)*10]
            print(name,number)
            webpg = MLA_contactinfo.objects.get_or_create(Name=name,PhoneNo = number)[0]

if __name__=='__main__':
    print('populating scripts')
    populate()
    print('populating completed')
