import requests
import pandas as pd
from bs4 import BeautifulSoup
s = requests.Session()
X = s.get('https://aplegislature.org/web/legislative-assembly/member-s-information')
count=0
if X.status_code == 200:
	print('started')
	print(count)
	count+=1
	soup = BeautifulSoup(X.content, "html.parser")
	div = soup.find("ul", attrs={"class": "table1"})
	names = []
	phone_Numbers = []
	for a in div.find_all('div',attrs={"class":"data"}):
		url = a.find('a',href=True)['href']
		soup = BeautifulSoup(s.get(url).content,"html.parser")
		table = soup.find("table",attrs = {'id':'table'})
		contents = table.find_all('tr')
		name = contents[0]
		names.append(name.find('span').text)
		Phno = contents[7]
		phone_Numbers.append(Phno.find_all('td')[1].text.replace(';','').replace(' ','').replace('-',''))
	dict = {'name': names, 'Phno': phone_Numbers}   
	df = pd.DataFrame(dict) 
	df.to_csv('data.csv') 
































































































