import requests
import pandas as pd
url = "https://mpa.gov.in/bills-list"
html = requests.get(url,verify=False).content
df_list = pd.read_html(html)
df = df_list[-1]
print(df)
# with open('c.csv', 'w', newline='') as file:
#         writer = csv.writer(file)
#         writer.writerows(df_list)
my_df = pd.DataFrame(df)
my_df.to_csv('b.csv', index=False, header=False)
my_df.describe
# with open("a.csv", "w", newline="") as f:
#     writer = csv.writer(f)
#     writer.writerows(['S.No', 'Title', 'Ministry', 'Introduced in LS/RS','Passed in LS','Passed in RS'])
#     writer.writerows(df_list)
