from requests_html import HTML, HTMLSession
import csv
#HTMLSession is used to pass the html code in the url directly to this file
#first we import HTML class from request_html then pass the delete.py file to request_html 

'''
with open('delete.html') as html_file:
    source = html_file.read()
    html = HTML(html=source)

'''
csv_file = open('mla_db.csv','w',newline='')
csv_writer = csv.writer(csv_file)
csv_writer.writerow(['photo_link','name','portfolio','details'])


# line 4,5,6 are used to pass the html file delete.html to HTML class which is imported.
# now 'html' is the instance of the class. if we want to print the html which is present
# in the object we just need to say 'html.html'.(calling the html attribute inside the object)
# 'html.text' is used to print just the text inside the html.
#print(html.html)
#print(html.text)
# dynamiclly generated content is printed in a different format in the output.
#match = html.find('title')
#print(match[0].html)
#print(match[0].text)
'''
match = html.find('title',first=True)
print(match.text+'\n')
match2 = html.find('#footer',first=True)
print(match2.text+'\n')
article = html.find('div.article',first=True)
print(article.text)
'''
"""
articles = html.find('div.article')

for article in articles:
    header = article.find('h2',first=True).text
    summary = article.find('p',first=True).text
    print(header)
    print(summary)
    print()
"""
session = HTMLSession() 
r = session.get('http://www.ap.gov.in/?page_id=54') # the session object uses a request library to get a response.
# 'r' is the response object

# print(r.html) # this gives us the html object of the webpage.
  
profiles = r.html.find('div.profile-list')
profiles2 = r.html.find('div.profile-list alt')
#print(profile.find('div.photo img',first=True).attrs['src'])

for profile in profiles:
    photo = profile.find('div.photo img',first=True).attrs['src']
    print(photo)
    print('\n')
    name =  profile.find('div.minister-name',first=True).text
    print(name)
    print('\n')
    portfolio =  profile.find('div.portfolio',first=True).text
    print(portfolio)
    print('\n')
    details =  profile.find('div.details',first=True).text
    print(details)
    csv_writer.writerow([photo, name, portfolio, details])
    print('######################')
#     '''
#     try:
#         vid_src = article.find('iframe',first=True).attrs['src']
#         vid_div = vid_src.split('/')
#         vid_div = vid_div[4].split('?')[0]
#         yt_link = f"https://youtube.com/watch?v={vid_div}"
#     except Exception as e:
#         yt_link = None
#     print()
#     print(yt_link)
#     print()
#     csv_writer.writerow([headline, summary, yt_link])

csv_file.close()
# '''
