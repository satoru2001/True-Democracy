from django.contrib import admin
from sign_up.models import UserProfileInfo,Info,MLA_contactinfo
# Register your models here.
admin.site.register(UserProfileInfo)
admin.site.register(Info)
admin.site.register(MLA_contactinfo)
