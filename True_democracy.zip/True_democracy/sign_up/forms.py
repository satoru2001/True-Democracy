from django import forms
from django.core import validators
from django.contrib.auth.models import User
from sign_up.models import UserProfileInfo,MLA_contactinfo
# from django.shortcuts import get_object_or_404, render


class UserProfileInfoForm(forms.ModelForm):
	verify_Phno2 = forms.CharField(label='Enter your number again')
	PhNo2 = forms.CharField(label = 'Current_PhoneNumber',widget=forms.TextInput(),validators = [validators.MinLengthValidator(10)])
	Name = forms.CharField(label = 'Name',widget=forms.TextInput())
	def clean(self):
		isMLA = self.cleaned_data['isMLA']
		vPhNo2 = self.cleaned_data['verify_Phno2']
		name = self.cleaned_data['Name']
		aPhNo2 = self.cleaned_data['PhNo2']
		if UserProfileInfo.objects.filter(Aadhar_id=self.cleaned_data['Aadhar_id']).exists():
			raise forms.ValidationError("AADHAR already enrolled")
		if aPhNo2!=vPhNo2:
			raise forms.ValidationError("Phone Numbers Donot Match")
		if len(name) == 0:
			raise forms.ValidationError("Invalid Name")
		if isMLA == 'mla':
			if not MLA_contactinfo.objects.filter(PhoneNo=aPhNo2).exists():
				raise forms.ValidationError("Sorry You Are NOT AN MLA")
	class Meta():
		model = UserProfileInfo
		fields = ('isMLA','Aadhar_id','PhNo2','verify_Phno2','Name','profile_pic')

class UserForm(forms.ModelForm):
	password = forms.CharField(widget=forms.PasswordInput())
	email = forms.EmailField(required = True)
	verify_password = forms.CharField(widget=forms.PasswordInput())
	verify_email = forms.EmailField(label='Reenter Email',widget=forms.EmailInput(attrs={'placeholder': 'Enter Your Email Again'}))
	def clean(self):
		password = self.cleaned_data['password']
		vpassword = self.cleaned_data['verify_password']
		email = self.cleaned_data['email']
		vmail = self.cleaned_data['verify_email']
		if User.objects.filter(username=self.cleaned_data['username']).exists():
			raise forms.ValidationError("User already exists")
		if password!=vpassword:
			raise forms.ValidationError("Password Donot Match")
		if email!=vmail:
			raise forms.ValidationError("Email Doesnot Match")
	class Meta():
		model = User
		fields = ('username','password','verify_password','email','verify_email')
