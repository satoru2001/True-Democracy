from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class MLA_contactinfo(models.Model):
	Name = models.CharField('Name',max_length=264,blank=False)
	PhoneNo = models.CharField('Mobile',max_length=10,blank=False)

class UserProfileInfo(models.Model):
	user = models.OneToOneField(User,on_delete=models.CASCADE)
	#Additional
	Aadhar_id = models.CharField('AADHAR',max_length=12,unique = True,blank = False)
	PhNo2 = models.CharField('PhNo2',max_length=10,blank = False)
	Name = models.CharField('Name',max_length=150,blank=False)
	isMLA = models.CharField('isMLA',max_length=10,blank=True)
	profile_pic = models.ImageField(upload_to='profile_pic',blank=True)
	def __str__(self):
		return self.Aadhar_id
		
class Info(models.Model):
	SNo= models.CharField(max_length=10,unique = True,blank = False)
	Title = models.CharField(max_length=264)
	Ministry = models.CharField(max_length=264)
	IntroducedinLSRS = models.CharField(blank=True,max_length=264)
	PassedinLS = models.CharField(blank=True,max_length=264)
	PassedinRS = models.CharField(blank=True,max_length=264)

	def __str__(self):
		return self.Title

class Validate_otp(models.Model):
    otp = models.IntegerField()
    uid = models.CharField(max_length=12)
    def __str__(self):
        return self.uid