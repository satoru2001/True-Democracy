from django.conf.urls import url
from sign_up import views
from django.urls import path
from django.contrib.auth import views as auth_views
from django.contrib import admin
app_name = 'sign_up'

urlpatterns = [
	path('',views.register,name='register'),
    path('login/',views.user_login,name='login'),
    path('logout/',views.user_logout,name='logout'),
    path('profile/',views.profile,name='profile'),
    path('otp_validation/',views.otp_validation,name='otp_validation'),
] 
