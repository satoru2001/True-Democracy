
import requests
import datetime
time = datetime.datetime.now().isoformat()
xml = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Otp uid="252964095613" ac="public" sa="public" ver="2.5" txn="A122WER21SSD" ts=\""""+str(time)+"""\" lk="MBni88mRNM18dKdiVyDYCuddwXEQpl68dZAGBQ2nsOlGMzC9DkOVL5s" type="A">
 <Opts ch="01"/>
 <Signature>keystore Password: "public", Alias: "public"</Signature>
</Otp>"""
ans = requests.post("http://developer.uidai.gov.in/otp/2.5/public/2/5/MMxNu7a6589B5x5RahDW-zNP7rhGbZb5HsTRwbi-VVNxkoFmkHGmYKM", data=xml).text
print(ans)